exports.handler = (event, context, callback) => {
	const r = {
		statusCode: 200,
		headers: { 'content-type': 'application/json' },
		body: JSON.stringify({ success: true })
	};
	callback(null, r);
};